# 2026-10-18 新闻日报 Top 50

1. [演员吴越怒斥AI仿冒带货，微信视频号回应：账号已永久封禁，内容清空](https://www.thepaper.cn/newsDetail_forward_34274620) · 硬科技 · 综合分 123.0

2. [大麦通报肖战演唱会第一排门票25万元](https://www.thepaper.cn/newsDetail_forward_34273574) · 新消费 · 综合分 115.9

3. [生益科技：董事长提议回购2亿至3亿元A股股份](https://www.cls.cn/detail/2507621) · 金融 · 综合分 112.1

4. [Swisse斯维诗抗糖丸被检出铅超标，官方客服：相关批次未进入中国销售](https://www.thepaper.cn/newsDetail_forward_34274427) · 新消费 · 综合分 108.2

5. [央行副行长宣昌能出席全球主权债务圆桌会等会议并会见相关机构负责人](https://www.cls.cn/detail/2507573) · 金融 · 综合分 106.8

6. [微软取消与英国数据中心合作](https://m.weibo.cn/detail/5355393787102445) · 硬科技 · 综合分 105.9

7. [英伟达辟谣RTX5090停产：只是产能不足 不会断供](https://www.jiemian.com/article/15203805.html) · 硬科技 · 综合分 105.0

8. [澜起科技：独立董事提议回购3亿至5亿元A股股份](https://www.cls.cn/detail/2507625) · 金融 · 综合分 105.0

9. [“股债双杀”的CoreWeave——本轮AI崩盘的“风暴眼”](https://wallstreetcn.com/articles/3783851) · 硬科技 · 综合分 101.8

10. [俄圣彼得堡石油码头遭无人机袭击起火](https://www.jiemian.com/article/15203619.html) · 物流 · 综合分 99.3

11. [协鑫集团与巨融集团签署埃塞俄比亚LNG项目合作协议](https://www.cls.cn/detail/2507606) · 大宗 · 综合分 99.2

12. [上海超导3公里单根长带产线，计划于2027年产出产品](https://www.jiemian.com/article/15203712.html) · 硬科技 · 综合分 98.9

13. [东兴证券：前三季度净利润同比增长0.75%](https://www.jiemian.com/article/15203771.html) · 金融 · 综合分 98.1

14. [格科微：实控人提议回购1.5亿至3亿元股份](https://www.cls.cn/detail/2507626) · 金融 · 综合分 98.1

15. [中科曙光：董事长提议回购3亿元-5亿元公司股份](https://www.jiemian.com/article/15203751.html) · 金融 · 综合分 98.1

16. [养老专属理财密集上新](https://www.jiemian.com/article/15203725.html) · 金融 · 综合分 98.1

17. [曙光8000发布十大前沿成果](https://www.cls.cn/detail/2507570) · 硬科技 · 综合分 98.1

18. [越南央行要求贷款机构降息以支持经济增长](https://www.cls.cn/detail/2507662) · 金融 · 综合分 96.5

19. [欧洲央行行长：欧元区通胀率创新高但不必惊慌](https://www.jiemian.com/article/15203594.html) · 金融 · 综合分 96.3

20. [下周重磅日程：中国GDP、金融街论坛与APEC财长会、英伟达GTC、特斯拉Meta与宁德时代财报](https://wallstreetcn.com/articles/3783759) · 金融 · 综合分 94.7

21. [精准预测大跌的美银Hartnett：“卖出信号”已经结束，投资者将“11月中旬重返科技股”，关键看“芯片价格”](https://wallstreetcn.com/articles/3783850) · 硬科技 · 综合分 93.1

22. [鼎泰高科：董事长提议回购5000万元至1亿元A股股份](https://www.cls.cn/detail/2507717) · 金融 · 综合分 90.7

23. [财联社10月18日电，全球芯片LOF将于2026年10月19日开市起停牌，自2026年10月19日10:30起复牌。](https://www.cls.cn/detail/2507700) · 金融 · 综合分 89.5

24. [台积电日本JASM二厂获准转向3nm芯片生产](https://www.jiemian.com/article/15203786.html) · 硬科技 · 综合分 88.7

25. [马斯克反思DOGE：“政府内部”无法解决赤字，只有AI和机器人才能救美国](https://wallstreetcn.com/articles/3783841) · 硬科技 · 综合分 88.3

26. [中国稀土集团与哈电集团签署战略合作框架协议](https://www.cls.cn/detail/2507589) · 大宗 · 综合分 85.5

27. [盛和资源：拟向中稀发展转让4家稀土冶炼分离子公司51%股权](https://www.jiemian.com/article/15203891.html) · 大宗 · 综合分 84.9

28. [北部湾港集团自平陆运河通航以来完成运河货物过货量突破100万吨](https://www.cls.cn/detail/2507552) · 物流 · 综合分 84.9

29. [经济高压下的韩国择偶新图景：韩日情侣渐多、海力士马甲成相亲“战袍”](https://www.thepaper.cn/newsDetail_forward_34269747) · 硬科技 · 综合分 84.7

30. [中信建投：宽基ETF持续净申购有望为后市核心指数的企稳修复提供支持](https://www.cls.cn/detail/2507721) · 金融 · 综合分 83.9

31. [Deepseek公布API网页搜索与抓取费用：每1000次成功请求5元](https://www.jiemian.com/article/15204049.html) · 硬科技 · 综合分 83.9

32. [中信证券：银行业绩稳定性有望进一步夯实稳定回报属性](https://www.jiemian.com/article/15203999.html) · 金融 · 综合分 83.9

33. [中信证券：证券板块业绩韧性仍存，关注券商“新红利”价值](https://www.jiemian.com/article/15203988.html) · 金融 · 综合分 83.9

34. [恒力石化：预计前三季度净利润同比增长104.20%](https://www.jiemian.com/article/15203908.html) · 大宗 · 综合分 83.9

35. [博盈特焊：筹划购买苏州罗克莱海洋装备股份有限公司，股票停牌](https://www.jiemian.com/article/15203776.html) · 大宗 · 综合分 83.9

36. [信达证券：前三季度净利润同比下降4.83%](https://www.jiemian.com/article/15203763.html) · 金融 · 综合分 83.9

37. [特朗普重申伊朗战争将很快结束，汽油价格将会回落](https://www.jin10.com/) · 大宗 · 综合分 82.6

38. [对冲基金今年收益已“蒸发一半”，近几周“亏损尤其惨重”，高盛合伙人：要等“垃圾级”资产止跌](https://wallstreetcn.com/articles/3783857) · 金融 · 综合分 80.2

39. [AI竞争打到工厂，欧洲想和中国掰手腕](https://news.ifeng.com/c/8xKApDsNCxa) · 硬科技 · 综合分 78.6

40. [美国副总统万斯：如果任由伊朗掌控霍尔木兹海峡航运，全球能源供应将受限，汽油价格会随之上涨。这场冲突结束之后，我们将会看到汽油价格回落。美军保障石油顺利通过霍尔木兹海峡。](https://www.jin10.com/) · 物流 · 综合分 77.8

41. [马斯克称解决美国国债问题唯一办法是AI和机器人](https://www.cls.cn/detail/2507538) · 硬科技 · 综合分 75.5

42. [国务院新闻办公室将于2026年10月19日（星期一）下午3时举行新闻发布会，请商务部部长助理袁晓明和工业和信息化部、文化和旅游部有关负责人介绍加快推进科技兴商有关情况，并答记者问。](http://www.scio.gov.cn/xwfb/fbhyg_13737/zxyg/202610/t20261016_1012720.html) · 新消费 · 综合分 75.4

43. [Anthropic据悉探讨AI智能体谈判规则，正寻求法律界建议](https://www.jin10.com/) · 硬科技 · 综合分 74.6

44. [一周展望：纳指创6月以来最差单周表现，黄金4200关口再遇阻：下周能否迎来反转？](https://xnews.jin10.com/details/232741) · 大宗 · 综合分 74.1

45. [中信证券： 市场对通胀的定价力量正在快速衰竭，长端定价锚已明确切向“增长/AI周期”](https://www.jin10.com/) · 硬科技 · 综合分 73.8

46. [日本拟加强海关执法，严打黄金走私与骗取退税](https://www.jin10.com/) · 大宗 · 综合分 73.1

47. [外骨骼机器人价格低至千元医用外骨骼康复纳入多地医保](https://m.weibo.cn/detail/5355386741195391) · 硬科技 · 综合分 72.7

48. [黄金投资者周报上新！](https://xnews.jin10.com/details/232774) · 大宗 · 综合分 72.1

49. [OpenAI发力人形机器人研发 将AI大脑作为核心突破口](https://www.cls.cn/detail/2507648) · 硬科技 · 综合分 71.8

50. [首发即售罄！库克说iPhoneDuo中国独家制造 库克说中国折叠屏市场首屈一指](https://m.weibo.cn/detail/5355460728983601) · 硬科技 · 综合分 71.6
