# 2026-10-19 新闻日报 Top 50

1. [今年前三季度GDP公布](https://finance.sina.com.cn/jjxw/2026-10-19/doc-inivtuen0899277.shtml) · 金融 · 综合分 118.9

2. [财联社10月19日电，央行今日开展800亿元7天期逆回购操作，操作利率为1.40%，与此前持平。](https://www.cls.cn/detail/2507872) · 金融 · 综合分 113.6

3. [英伟达GTC柏林大会即将开幕，黄仁勋将发表主题演讲](https://www.cls.cn/detail/2508202) · 硬科技 · 综合分 112.0

4. [商务部新闻发言人就优化调整无人机相关物项出口管制措施答记者问](https://www.jiemian.com/article/15206948.html) · 硬科技 · 综合分 109.8

5. [伊朗称一艘违规油轮在霍尔木兹海峡南部触雷爆炸起火](https://www.cls.cn/detail/2507766) · 物流 · 综合分 107.8

6. [国家统计局：规模以上制造业人工智能技术重点场景应用普及率超过1/3](https://finance.sina.com.cn/roll/2026-10-19/doc-inivtuen0914949.shtml) · 硬科技 · 综合分 105.7

7. [国家统计局：“人工智能+”行动有力带动了新兴领域的投资和出口](https://finance.sina.com.cn/jjxw/2026-10-19/doc-inivtpwt6231708.shtml) · 硬科技 · 综合分 105.5

8. [三星据悉将采用台积电3纳米工艺为英伟达生产下一代HBM基底裸片](https://www.cls.cn/detail/2507805) · 硬科技 · 综合分 105.2

9. [丁向群会见美国桥水投资公司创始人瑞·达利欧](https://www.jiemian.com/article/15206688.html) · 金融 · 综合分 104.0

10. [财政部决定开展国债做市支持操作](https://www.jiemian.com/article/15206308.html) · 金融 · 综合分 104.0

11. [美联储10月维持利率不变的概率为83.9%](https://www.cls.cn/detail/2507769) · 金融 · 综合分 103.9

12. [A股农业种植板块震荡走弱，金健米业跌停，秋乐种业、万向德农、敦煌种业、亚盛集团、新赛股份、新农开发等跟跌。](https://www.jin10.com/) · 金融 · 综合分 103.6

13. [前三季度深圳集成电路等人工智能相关零部件进出口规模居全国首位](https://finance.sina.com.cn/jjxw/2026-10-19/doc-inivtpwr7679801.shtml) · 硬科技 · 综合分 103.5

14. [阿里达摩院孟建熠：玄铁芯片目前已经稳定出货超60亿颗](https://www.cls.cn/detail/2508096) · 硬科技 · 综合分 102.7

15. [国产卫星互联网首次实现北极、南极、青藏高原联网通信](https://www.cls.cn/detail/2508015) · 硬科技 · 综合分 102.7

16. [Swisse抗糖丸被检出铅超标，公司回应：涉及批次仅存在于澳洲，从未进入中国市场](https://www.jiemian.com/article/15204512.html) · 新消费 · 综合分 102.6

17. [山姆回应AI造假恶意攻击](https://www.jiemian.com/article/15205662.html) · 硬科技 · 综合分 100.4

18. [焦煤连续主力合约日内跌6%](https://www.cls.cn/detail/2508178) · 大宗 · 综合分 100.2

19. [Anthropic计划将部分股份转入新型“公共利益”基金](https://www.cls.cn/detail/2507749) · 金融 · 综合分 100.2

20. [富时中国A50指数期货盘初跌0.29%](https://www.cls.cn/detail/2507973) · 金融 · 综合分 100.1

21. [宇树科技盘中涨超16%，总市值重返2000亿上方](https://www.jiemian.com/article/15206484.html) · 金融 · 综合分 99.7

22. [韩国KOSPI指数低开3.17% SK海力士跌逾4%](https://www.cls.cn/detail/2507810) · 金融 · 综合分 99.4

23. [呼和浩特低空经济再添重磅项目，快轮科技二期开工](https://www.jiemian.com/article/15204632.html) · 硬科技 · 综合分 99.2

24. [丁向群会见安达集团董事长兼首席执行官埃文·格林伯格](https://www.jiemian.com/article/15206706.html) · 金融 · 综合分 99.1

25. [国家发改委向社会公开征求《电力现货市场基本规则（公开征求意见稿）》意见](https://www.cls.cn/detail/2508077) · 新能源 · 综合分 99.1

26. [国家统计局：2026年1—9月份社会消费品零售总额增长1.1%](https://www.jiemian.com/article/15205045.html) · 新消费 · 综合分 99.1

27. [九部门：深入实施“人工智能+制造”专项行动](https://www.cls.cn/detail/2507941) · 硬科技 · 综合分 99.0

28. [日本央行行长植田和男称潜在通胀率非常接近2%](https://www.cls.cn/detail/2507857) · 金融 · 综合分 98.6

29. [韩国KOSPI指数日内涨幅达1%](https://www.cls.cn/detail/2508072) · 金融 · 综合分 98.1

30. [前三季度我国工业机器人产量同比增长29.1%](https://www.cls.cn/detail/2507930) · 硬科技 · 综合分 98.1

31. [两市融资余额减少144.05亿元](https://www.jiemian.com/article/15204513.html) · 金融 · 综合分 98.1

32. [中信证券：看好国产大模型持续崛起](https://www.jiemian.com/article/15204472.html) · 硬科技 · 综合分 98.1

33. [财联社10月19日电，日本央行行长植田和男称，基础通胀接近我们的2%目标。日本正迎来工资上涨、物价回升的良性循环。](https://www.cls.cn/detail/2507814) · 金融 · 综合分 97.3

34. [汇源集团回应与“汇源”品牌切割](https://www.jiemian.com/article/15204856.html) · 新消费 · 综合分 95.5

35. [人民币兑美元中间价报6.7208](https://www.jiemian.com/article/15204644.html) · 金融 · 综合分 95.5

36. [“山姆品质暴跌你还敢去吗”热搜第一，山姆会员商店相关负责人回应每经：热搜视频系AI造假](https://finance.sina.com.cn/roll/2026-10-19/doc-inivtpwv6999884.shtml) · 硬科技 · 综合分 94.8

37. [WTI原油日内跌2.04%失守97美元/桶](https://www.cls.cn/detail/2508232) · 大宗 · 综合分 94.7

38. [AI与涨价双轮驱动 逾130家A股公司三季报预喜](https://www.cls.cn/detail/2507771) · 硬科技 · 综合分 94.7

39. [国家统计局：9月份规上工业原煤生产降幅收窄，原油生产增速加快](https://www.jiemian.com/article/15205094.html) · 大宗 · 综合分 92.0

40. [Anthropic拟拿出5%股份做公益 应对AI冲击就业等问题](https://www.cls.cn/detail/2508024) · 硬科技 · 综合分 91.8

41. [财联社10月19日电，据报道，英国央行对巴克莱银行展开审查，指控其交易员虚报私募信贷敞口。](https://www.cls.cn/detail/2508087) · 金融 · 综合分 91.5

42. [丰田将在泰国投资4400万美元生产燃料电池皮卡](https://www.cls.cn/detail/2508180) · 汽车 · 综合分 90.9

43. [EQT宣布以65亿美元收购澳大利亚废弃物管理公司Cleanaway](https://www.cls.cn/detail/2507808) · 金融 · 综合分 90.9

44. [鸿海将出资约7.27亿美元收购三菱电机电动汽车零部件业务50%股权](https://www.cls.cn/detail/2508152) · 汽车 · 综合分 90.7

45. [财联社10月19日电，TD COWEN将高通目标价从175美元上调至200美元。](https://www.cls.cn/detail/2508071) · 硬科技 · 综合分 90.7

46. [央视启动全国中短剧精品共创计划](https://finance.sina.com.cn/stock/wbstock/2026-10-19/doc-inivtpwr7706265.shtml) · 新消费 · 综合分 90.0

47. [比特币升破83000美元](https://www.cls.cn/detail/2508455) · 金融 · 综合分 89.9

48. [布伦特原油期货跌幅扩大至2%](https://www.cls.cn/detail/2508209) · 大宗 · 综合分 89.9

49. [A股汽车整车板块活跃，金龙汽车涨停，江铃汽车、中集车辆、中国重汽、比亚迪、宇通客车跟涨。](https://www.jin10.com/) · 金融 · 综合分 89.9

50. [小马智行旗下广州小马慧行公司增资至5.29亿美元](https://www.jiemian.com/article/15206926.html) · 硬科技 · 综合分 89.7
